package com.livedashcam.newapp

import android.content.ContentValues
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Navy = Color(0xFF07111F)
private val Panel = Color(0xFF122338)
private val Blue = Color(0xFF1685FF)
private val Mint = Color(0xFF39E6C1)
private data class Recording(val path:String,val size:Long,val timestamp:String) { val name get()=File(path).name }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { LiveDashcamApp() } }

    @Composable private fun LiveDashcamApp() {
        val context = LocalContext.current
        var host by remember { mutableStateOf("192.168.169.1") }
        var liveUrl by remember { mutableStateOf("rtsp://192.168.169.1:2222/streamtype=0") }
        var liveAiEnabled by remember { mutableStateOf(true) }
        var folder by remember { mutableStateOf("loop") }
        var recordings by remember { mutableStateOf(listOf<Recording>()) }
        var downloaded by remember { mutableStateOf(listOf<File>()) }
        var selected by remember { mutableStateOf<Recording?>(null) }
        var localSelected by remember { mutableStateOf<File?>(null) }
        var tab by remember { mutableStateOf("Home") }
        var status by remember { mutableStateOf("Connect phone to dashcam Wi-Fi, then load recordings.") }
        var busy by remember { mutableStateOf(false) }
        var search by remember { mutableStateOf("") }
        var analysis by remember { mutableStateOf("") }
        var keepDays by remember { mutableIntStateOf(7) }
        var autoDelete by remember { mutableStateOf(false) }
        var deleteWhenFull by remember { mutableStateOf(true) }
        var motionFilter by remember { mutableStateOf("All") }
        val player = remember { ExoPlayer.Builder(context).build() }
        DisposableEffect(Unit) { onDispose { player.release() } }

        fun refreshLocal() { downloaded = filesDir.listFiles()?.filter { it.isFile && (it.extension.lowercase() in listOf("ts","mp4","mov","m4v")) }?.sortedByDescending { it.lastModified() } ?: emptyList() }
        LaunchedEffect(Unit) { refreshLocal() }
        MaterialTheme(colorScheme = darkColorScheme(primary=Blue, secondary=Mint, background=Navy, surface=Panel)) {
            Column(Modifier.fillMaxSize().background(Navy)) {
                Row(Modifier.fillMaxWidth().padding(horizontal=16.dp, vertical=12.dp), verticalAlignment=Alignment.CenterVertically) {
                    Image(painterResource(R.drawable.livedashcam_logo), contentDescription="LiveDashcam logo", modifier=Modifier.size(54.dp))
                    Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text("LiveDashcam", color=Color.White, style=MaterialTheme.typography.titleLarge, fontWeight=FontWeight.Bold); Text("DRIVE SAFE • RECORD • STAY SAFE", color=Mint, style=MaterialTheme.typography.labelSmall) }
                    Text("●", color=Mint); Text(" READY", color=Color.LightGray, style=MaterialTheme.typography.labelSmall)
                }
                Row(Modifier.fillMaxWidth().padding(horizontal=10.dp), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    listOf("Home","Recordings","Player","Live","Downloads","AI","Settings").forEach { item -> FilterChip(selected=tab==item,onClick={tab=item},label={Text(item)},colors=FilterChipDefaults.filterChipColors(selectedContainerColor=Blue,selectedLabelColor=Color.White)) }
                }
                when(tab) {
                    "Home" -> Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                        Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(20.dp)) { Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                            Text("DASHCAM CONNECTION",color=Mint,style=MaterialTheme.typography.labelLarge); Spacer(Modifier.height(10.dp)); Text("📷",style=MaterialTheme.typography.displayMedium); Text("Connect to your dashcam Wi-Fi",color=Color.White,style=MaterialTheme.typography.titleMedium); Text("Optional live preview • editable URL",color=Color.LightGray); Spacer(Modifier.height(12.dp))
                            OutlinedTextField(value=host,onValueChange={host=it},label={Text("Camera IP address")},singleLine=true)
                            Button(onClick={ busy=true; status="Checking camera…"; lifecycleScope.launch { try { val result=withContext(Dispatchers.IO){loadCamera(host,folder)}; recordings=result; status="${result.size} recordings found in ${folder.uppercase()}"; tab="Recordings" } catch(e:Exception){status="Connection failed: ${e.message}"} finally{busy=false} } },enabled=!busy,modifier=Modifier.fillMaxWidth()) { Text(if(busy) "Connecting…" else "Load recordings") }
                        } }
                        Text(status,color=Color.LightGray); Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) { HomeTile("Recordings","${recordings.size} found",Modifier.weight(1f)){tab="Recordings"}; HomeTile("Downloaded","${downloaded.size} files",Modifier.weight(1f)){refreshLocal();tab="Downloads"} }
                        HomeTile("Playback workflow","Choose a recording → Preview → Download only if needed",Modifier.fillMaxWidth()){tab="Recordings"}
                        Text("Camera-side delete is disabled until the camera's delete API is verified.",color=Color(0xFFFFC46B),style=MaterialTheme.typography.bodySmall)
                    }
                    "Recordings" -> Column(Modifier.fillMaxSize().padding(12.dp)) {
                        Text("SD CARD RECORDINGS",color=Color.White,style=MaterialTheme.typography.titleLarge); Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) { listOf("loop","event","park","emr").forEach { f->FilterChip(selected=folder==f,onClick={folder=f},label={Text(f.uppercase())}) } }
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { Button(onClick={busy=true;lifecycleScope.launch{try{recordings=withContext(Dispatchers.IO){loadCamera(host,folder)};status="${recordings.size} recordings found"}catch(e:Exception){status="${e.message}"}finally{busy=false}}},enabled=!busy){Text("Refresh")}; Text(status,color=Color.LightGray,modifier=Modifier.align(Alignment.CenterVertically)) }
                        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) { items(recordings) { r -> Card(Modifier.fillMaxWidth().clickable { selected=r; localSelected=null; playUrl("http://$host${r.path}",player); tab="Player" },colors=CardDefaults.cardColors(containerColor=Panel)) { Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically) { Text("▶",color=Blue,style=MaterialTheme.typography.headlineSmall); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(r.name,color=Color.White,fontWeight=FontWeight.SemiBold); Text("${r.timestamp} • ${formatSize(r.size)}",color=Color.LightGray,style=MaterialTheme.typography.bodySmall); Text("Tap to preview • no full download first",color=Mint,style=MaterialTheme.typography.labelSmall) }; Button(onClick={selected=r;localSelected=null;playUrl("http://$host${r.path}",player);tab="Player"}){Text("Preview")} } } } }
                    }
                    "Live" -> Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                        Text("OPTIONAL LIVE PREVIEW",color=Color.White,style=MaterialTheme.typography.titleLarge)
                        Text("Paste or edit a future RTSP/HTTP stream URL. Leave this unused if you only want recordings.",color=Color.LightGray,style=MaterialTheme.typography.bodySmall)
                        OutlinedTextField(value=liveUrl,onValueChange={liveUrl=it},label={Text("Live stream URL")},modifier=Modifier.fillMaxWidth(),singleLine=false,minLines=2)
                        Button(onClick={try { if(!liveUrl.startsWith("http://") && !liveUrl.startsWith("https://") && !liveUrl.startsWith("rtsp://")) error("Use an http(s) or rtsp URL"); selected=null;localSelected=null;player.setMediaItem(MediaItem.fromUri(liveUrl.trim()));player.prepare();player.playWhenReady=true;status="Trying live URL. Playback depends on camera URL, codec and network support." } catch(e:Exception){status="Live URL error: ${e.message}"}},modifier=Modifier.fillMaxWidth()){Text("▶ Connect & Play Live")}
                        AndroidView(factory={ ctx -> PlayerView(ctx).apply { this.player=player; useController=true; setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS) } },modifier=Modifier.fillMaxWidth().height(240.dp))
                        Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Enable AI tools for live mode",color=Color.White);Text("Preference only; live-frame AI requires compatible frame capture/model integration.",color=Color.LightGray,style=MaterialTheme.typography.bodySmall)};Switch(checked=liveAiEnabled,onCheckedChange={liveAiEnabled=it})}
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={analysis="Live AI pipeline: motion, object/vehicle detection, incident classification, plate OCR, highlights and summaries are planned for compatible live frames. The current source does not yet run these models on live frames."}){Text("Live AI status")};OutlinedButton(onClick={player.stop()}){Text("Stop live")}}
                        Text(status,color=Mint)
                    }
                    "Player" -> Column(Modifier.fillMaxSize().padding(12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                        Text(localSelected?.name ?: selected?.name ?: "Select a recording",color=Color.White,style=MaterialTheme.typography.titleMedium)
                        AndroidView(factory={ ctx -> PlayerView(ctx).apply { this.player=player; useController=true; setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS) } },modifier=Modifier.fillMaxWidth().height(240.dp))
                        Text("Preview streams from the camera where supported. Download is optional.",color=Color.LightGray,style=MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            Button(onClick={ val r=selected; if(r!=null){busy=true;status="Downloading ${r.name}…";lifecycleScope.launch{try{val f=withContext(Dispatchers.IO){downloadFile(host,r)};refreshLocal();localSelected=f;selected=null;playUrl(Uri.fromFile(f).toString(),player);status="Saved ${f.name}"}catch(e:Exception){status="Download failed: ${e.message}"}finally{busy=false}}} },enabled=selected!=null&&!busy,modifier=Modifier.weight(1f)){Text(if(busy)"Downloading…" else "⬇ Download")}
                            OutlinedButton(onClick={selected=null;localSelected=null;player.stop();status="Preview closed"},modifier=Modifier.weight(1f)){Text("Skip / Close")}
                        }
                        if(localSelected!=null) Button(onClick={localSelected?.let{exportToGallery(it)};status="Gallery export requested";},modifier=Modifier.fillMaxWidth()){Text("Save to Gallery")}
                        Text(status,color=Mint)
                    }
                    "Downloads" -> Column(Modifier.fillMaxSize().padding(12.dp)) { Text("PHONE ALBUM",color=Color.White,style=MaterialTheme.typography.titleLarge); Text("Local copies only. Deleting here never deletes the dashcam original.",color=Color.LightGray,style=MaterialTheme.typography.bodySmall); Spacer(Modifier.height(8.dp)); Button(onClick={refreshLocal()}){Text("Refresh album")}; LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(downloaded){f->Card(colors=CardDefaults.cardColors(containerColor=Panel),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){Text(f.name,color=Color.White);Text("${formatSize(f.length())} • ${Date(f.lastModified())}",color=Color.LightGray,style=MaterialTheme.typography.bodySmall);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={localSelected=f;selected=null;playUrl(Uri.fromFile(f).toString(),player);tab="Player"}){Text("Play")};OutlinedButton(onClick={lifecycleScope.launch{analysis=withContext(Dispatchers.IO){analyzeMotion(f)};status=analysis;tab="AI"}}){Text("Motion check")};OutlinedButton(onClick={f.delete();refreshLocal();status="Local copy deleted"}){Text("Delete local")}}}}}} }
                    "AI" -> Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                        Text("ON-DEVICE VIDEO TOOLS",color=Color.White,style=MaterialTheme.typography.titleLarge); Text("Local clip analysis is available here. Live AI settings are in the Live tab; full live-frame model processing still requires implementation.",color=Color.LightGray)
                        Button(onClick={val f=localSelected ?: downloaded.firstOrNull(); if(f==null) analysis="Download a clip first." else {busy=true;analysis="Analyzing motion…";lifecycleScope.launch{analysis=withContext(Dispatchers.IO){analyzeMotion(f)};busy=false}},modifier=Modifier.fillMaxWidth(),enabled=!busy){Text("Analyze motion in latest downloaded clip")}
                        Button(onClick={val f=localSelected ?: downloaded.firstOrNull();if(f==null)analysis="Download a clip first." else {busy=true;analysis="Reading text…";recognizeText(f){out->analysis=out;busy=false}},modifier=Modifier.fillMaxWidth(),enabled=!busy){Text("Read text / possible number plate (OCR)")}
                        Button(onClick={val f=localSelected ?: downloaded.firstOrNull();if(f==null)analysis="Download a clip first." else {busy=true;analysis="Detecting objects in a sampled frame…";detectObjects(f){out->analysis=out;busy=false}},modifier=Modifier.fillMaxWidth(),enabled=!busy){Text("Detect objects in clip frame")}
                        Button(onClick={val f=localSelected ?: downloaded.firstOrNull();if(f==null)analysis="Download a clip first." else {busy=true;analysis="Generating basic clip summary…";lifecycleScope.launch { val motion=withContext(Dispatchers.IO){analyzeMotion(f)}; recognizeText(f){ocr->analysis="Clip: ${f.name}\nSize: ${formatSize(f.length())}\nMotion analysis: $motion\nReadable text: $ocr\nNote: summary is based on sampled frames; it is not an accident verdict.";busy=false } }},modifier=Modifier.fillMaxWidth(),enabled=!busy){Text("Create basic clip summary")}

                        Card(colors=CardDefaults.cardColors(containerColor=Panel)){Text(analysis.ifBlank { "Results will appear here. Motion scoring is a simple frame-change heuristic, not a validated crash detector. OCR can misread plates." },color=Color.White,modifier=Modifier.padding(14.dp))}
                        Text("Object detection, reliable incident classification, highlights and summaries require a validated on-device vision model; they are not represented as completed here.",color=Color(0xFFFFC46B),style=MaterialTheme.typography.bodySmall)
                    }
                    else -> Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                        Text("STORAGE & PRIVACY",color=Color.White,style=MaterialTheme.typography.titleLarge)
                        Text("Motion clips retention: $keepDays days",color=Color.White); Slider(value=keepDays.toFloat(),onValueChange={keepDays=it.toInt().coerceIn(1,30)},valueRange=1f..30f,steps=28)
                        Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Auto-delete no-motion clips",color=Color.White);Text("Only eligible local copies",color=Color.LightGray,style=MaterialTheme.typography.bodySmall)};Switch(checked=autoDelete,onCheckedChange={autoDelete=it})}
                        Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Cleanup when storage is low",color=Color.White);Text("Protected clips should never be removed",color=Color.LightGray,style=MaterialTheme.typography.bodySmall)};Switch(checked=deleteWhenFull,onCheckedChange={deleteWhenFull=it})}
                        Button(onClick={val msg=if(autoDelete) "Auto-cleanup preference saved for this session. Automatic classification/deletion is not yet active." else "Settings saved for this session.";status=msg},modifier=Modifier.fillMaxWidth()){Text("Save settings")}
                        Text("No SD-card deletion command is enabled. These controls currently store session preferences only; safe scheduled cleanup still needs implementation/testing.",color=Color(0xFFFFC46B),style=MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    @Composable private fun HomeTile(title:String,sub:String,modifier:Modifier=Modifier,click:()->Unit){Card(modifier.clickable{click()},colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(16.dp)){Text(title,color=Color.White,fontWeight=FontWeight.Bold);Spacer(Modifier.height(5.dp));Text(sub,color=Color.LightGray,style=MaterialTheme.typography.bodySmall)}}}
    private fun loadCamera(host:String,folder:String):List<Recording>{
        val conn=URL("http://$host/app/getfilelist?folder=$folder&start=0&end=99").openConnection() as HttpURLConnection
        conn.connectTimeout=7000;conn.readTimeout=15000
        try{if(conn.responseCode !in 200..299) error("HTTP ${conn.responseCode}");val root=JSONObject(conn.inputStream.bufferedReader().use{it.readText()});if(root.optInt("result",-1)!=0)error("Camera result ${root.optInt("result")}");val out=mutableListOf<Recording>();val info=root.optJSONArray("info")?:return emptyList();for(i in 0 until info.length()){val entry=info.optJSONObject(i)?:continue;val arr=entry.optJSONArray("files")?:continue;for(k in 0 until arr.length()){val f=arr.optJSONObject(k)?:continue;val path=f.optString("name");if(path.startsWith("/"))out.add(Recording(path,f.optLong("size"),f.optString("createtimestr")))}};return out
        }finally{conn.disconnect()}
    }
    private fun playUrl(url:String,player:ExoPlayer){ player.setMediaItem(MediaItem.fromUri(url));player.prepare();player.playWhenReady=true }
    private fun downloadFile(host:String,r:Recording):File{
        val out=File(filesDir,r.name.removeSuffix(".ts")+".ts.part");val conn=URL("http://$host${r.path}").openConnection() as HttpURLConnection;conn.connectTimeout=10000;conn.readTimeout=60000;conn.setRequestProperty("Accept-Encoding","identity")
        try{if(conn.responseCode !in 200..299)error("HTTP ${conn.responseCode}");conn.inputStream.use{input->out.outputStream().use{output->val b=ByteArray(128*1024);while(true){val n=input.read(b);if(n<0)break;output.write(b,0,n)}}};val final=File(filesDir,r.name);if(final.exists())final.delete();if(!out.renameTo(final))error("Could not save file");return final} catch(e:Exception){out.delete();throw e} finally{conn.disconnect()}
    }
    private fun analyzeMotion(file:File):String{
        val retriever=MediaMetadataRetriever();try{retriever.setDataSource(file.absolutePath);val duration=(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?:0L)*1000;if(duration<=0)return "Could not read video duration. This format may not be supported.";var prev:IntArray?=null;var total=0L;var samples=0;val points=8;for(i in 0..points){val bmp=retriever.getFrameAtTime(duration*i/points,MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?:continue;val current=samplePixels(bmp);bmp.recycle();val p=prev;if(p!=null){var diff=0L;for(j in current.indices)diff+=kotlin.math.abs(current[j]-p[j]);total+=diff/current.size};prev=current;samples++};if(samples<2)return "Not enough readable frames to estimate motion.";val score=total/(samples-1);return "Motion scan complete. Frame-change score: $score. ${if(score>18)"Visual changes detected" else "Low visual change detected"}. This is a rough heuristic, not proof of motion or an incident."
        }catch(e:Exception){return "Motion analysis failed: ${e.message}"}finally{retriever.release()}}
    private fun samplePixels(b:Bitmap):IntArray{val w=16;val h=9;val scaled=Bitmap.createScaledBitmap(b,w,h,true);val out=IntArray(w*h);for(y in 0 until h)for(x in 0 until w){val c=scaled.getPixel(x,y);out[y*w+x]=((android.graphics.Color.red(c)*3+android.graphics.Color.green(c)*6+android.graphics.Color.blue(c))/10)};scaled.recycle();return out}
    private fun recognizeText(file:File,done:(String)->Unit){ lifecycleScope.launch(Dispatchers.IO){val retriever=MediaMetadataRetriever();try{retriever.setDataSource(file.absolutePath);val bitmap=retriever.getFrameAtTime(0,MediaMetadataRetriever.OPTION_CLOSEST_SYNC);if(bitmap==null){runOnUiThread{done("Could not extract a frame for OCR.")};return@launch};val image=InputImage.fromBitmap(bitmap,0);val recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);recognizer.process(image).addOnSuccessListener{result->val text=result.text.ifBlank{"No readable text found."};runOnUiThread{done("OCR text found (check manually; not verified plate recognition):\n$text")};bitmap.recycle();recognizer.close()}.addOnFailureListener{e->runOnUiThread{done("OCR failed: ${e.message}")};bitmap.recycle();recognizer.close()}}catch(e:Exception){runOnUiThread{done("OCR error: ${e.message}")}}finally{retriever.release()}} }
    private fun detectObjects(file:File,done:(String)->Unit){
        lifecycleScope.launch(Dispatchers.IO){
            val retriever=MediaMetadataRetriever()
            try{
                retriever.setDataSource(file.absolutePath)
                val duration=(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?:0L)*1000
                val bitmap=retriever.getFrameAtTime((duration/2).coerceAtLeast(0L),MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                if(bitmap==null){runOnUiThread{done("Could not extract a frame for object detection.")};return@launch}
                val image=InputImage.fromBitmap(bitmap,0)
                val options=ObjectDetectorOptions.Builder().setDetectorMode(ObjectDetectorOptions.SINGLE_IMAGE_MODE).enableClassification().build()
                val detector=ObjectDetection.getClient(options)
                detector.process(image).addOnSuccessListener { objects ->
                    val report=if(objects.isEmpty()) "No objects detected in the sampled frame." else objects.mapIndexed { index, obj ->
                        val labels=obj.labels.joinToString { label -> "${label.text} (${(label.confidence*100).toInt()}%)" }.ifBlank { "unclassified object" }
                        "${index+1}. $labels"
                    }.joinToString("\n")
                    runOnUiThread{done("On-device object detection (one sampled frame):\n$report\nThis is general object detection, not validated vehicle tracking or crash detection.")}
                    bitmap.recycle();detector.close()
                }.addOnFailureListener { e -> runOnUiThread{done("Object detection failed: ${e.message}")};bitmap.recycle();detector.close() }
            }catch(e:Exception){runOnUiThread{done("Object detection error: ${e.message}")}}
            finally{retriever.release()}
        }
    }
    private fun exportToGallery(file:File){try{val values=ContentValues().apply{put(MediaStore.Video.Media.DISPLAY_NAME,file.name);put(MediaStore.Video.Media.MIME_TYPE,if(file.extension.lowercase()=="mp4")"video/mp4" else "video/mp2t");put(MediaStore.Video.Media.RELATIVE_PATH,"Movies/LiveDashcam")};val uri=contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,values)?:return;contentResolver.openOutputStream(uri)?.use{out->file.inputStream().use{it.copyTo(out)}}}catch(_:Exception){}}
    private fun formatSize(size:Long):String{if(size<1024)return "$size B";val kb=size/1024.0;if(kb<1024)return String.format(Locale.US,"%.1f KB",kb);return String.format(Locale.US,"%.1f MB",kb/1024.0)}
}
