# NightDrive — Drive + YouTube Website

## Website
`public/index.html` is a responsive Apple TV-inspired dark-mode front-end prototype.

## UI options included
- Google Drive recording-save preference
- Live-view-only / don't archive preference
- YouTube Live option with privacy preference (private/unlisted/public)
- Setup dialogs and local preference toggles

## Important
These controls currently save preferences in the browser only. They do NOT upload to Google Drive, stream a real camera feed, or broadcast to YouTube yet.

To make it fully working, implement:
1. Android bridge compatibility with the Oncord 4K / Viidure feed.
2. A secure backend for device pairing and stream relay.
3. Google OAuth + Drive API for actual file upload.
4. YouTube Live integration using YouTube's supported authorization and broadcast workflow.
5. Clear user consent and privacy controls before any live broadcast or recording.

Do not store Google refresh tokens or YouTube stream keys in browser local storage or public source code.

## Hosting and backup
- For a live website, deploy the `public` directory to a static hosting service such as Cloudflare Pages.
- For backup, upload this ZIP and/or `public/index.html` to a Google Drive folder named `NightDrive Website`.
- Google Drive stores the project files; it does not itself provide a production web server or live-stream backend.
