# LiveDashcam — expanded Android source project

Branded Android app source for the Oncord dashcam (Kotlin, Jetpack Compose, Media3/ExoPlayer). This project keeps Live Mode optional and editable; normal workflow is recordings list → in-app preview → user chooses Download or Skip.

## Included code
- Branded app header/logo and Home, Recordings, Player, Live, Downloads, AI, Settings screens.
- Camera IP field and recordings request using the observed endpoint `/app/getfilelist?folder=...&start=0&end=99`.
- Loop, event, park, emergency category selection (the firmware may not support every category).
- HTTP recording preview via Media3 using the observed direct path pattern `http://<camera-ip>/mnt/tfcard/record/record_0/<filename>`; actual playback depends on camera stream/file format and must be tested.
- Explicit local download of selected `.ts` recordings, app-private local album, local playback, local deletion, and Gallery export. Local deletion never sends a command to the dashcam SD card.
- Editable optional RTSP/HTTP/HTTPS Live URL and Media3 playback attempt.
- Downloaded-video frame-difference motion heuristic.
- ML Kit text recognition (OCR) on a sampled video frame.
- ML Kit on-device general object detection/classification on a sampled video frame.
- Basic clip summary composed from metadata, motion heuristic, and OCR output.
- Storage retention/cleanup preference controls. These are not yet connected to a background auto-deletion scheduler.

## Important limits (not hidden)
- Object detection is general-purpose ML Kit detection on one sampled frame; it is not a dedicated vehicle/person tracking model.
- OCR is not a number-plate detection/tracking system and may return unrelated text or misread plates.
- Motion score is a simple frame-change heuristic, not validated incident/crash detection.
- Live AI switch is currently a preference only. The app does not yet run the AI pipeline continuously over live frames.
- AI highlights, reliable incident classification, full-video semantic search, and validated summaries need dedicated models/pipelines and testing; they are not complete merely because UI controls exist.
- `.ts` to `.mp4` conversion/transcoding is not implemented. The app does not rename a file to fake conversion.
- Automatic cleanup scheduler and camera-side delete API are not implemented; no camera-original deletion command is issued.
- No successful Gradle build, APK installation, or physical dashcam playback test has been verified in this environment.

## Build
Open this folder in Android Studio with JDK 17 and Android SDK 35; sync Gradle and build a debug APK. Connect the Android phone to dashcam Wi-Fi `Oncord_DC_d86a`; default IP is `192.168.169.1` and can be edited in Home. First test recording list and preview, then test download and local playback.
