# LiveDashcam final source package — feature status

## Included in source
- Branded dark Compose UI with logo and Home / Recordings / Player / Live / Downloads / AI / Settings tabs.
- Editable camera IP and recording-folder selector.
- Recording-list request to `/app/getfilelist?folder=...&start=0&end=99`.
- Recording preview attempt using the observed direct file path.
- User-controlled download to app-private storage; local playback, local deletion and Gallery export.
- Optional editable RTSP/HTTP/HTTPS Live URL and Media3 playback attempt.
- Downloaded clip frame-change motion heuristic.
- ML Kit OCR on one sampled frame.
- ML Kit general object detection/classification on one sampled frame.
- Basic summary composed from file metadata, motion heuristic and OCR.
- Retention/cleanup preference controls in Settings.

## Not yet implemented / not verified
- No successful Gradle build or APK installation has been verified.
- Camera recording list parsing and in-app direct playback need testing against the actual firmware.
- Live playback depends on the actual URL, codec and protocol support; the live AI switch is a preference only.
- Continuous live AI, vehicle/person tracking, dedicated number-plate detection/tracking, reliable incident/crash detection, semantic search and AI highlights are not implemented.
- OCR is generic text recognition, not a dedicated license-plate model.
- Motion score is a rough frame-difference heuristic, not validated motion/incident classification.
- `.ts` to `.mp4` remux/transcode is not implemented.
- Automatic scheduled cleanup is not implemented; settings are preferences only.
- Dashcam SD-card deletion API is not verified; app only deletes local copies.

## Build instructions
1. Install Android Studio and JDK 17.
2. Open this project folder (`LiveDashcamComplete`) in Android Studio.
3. Allow Gradle sync; install Android SDK 35 if prompted.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Connect the phone to the dashcam Wi-Fi, launch the app, and test recordings list, preview, download, and local playback.

The source package is not a tested release APK. Test on the actual camera and phone before relying on it for important recordings.
